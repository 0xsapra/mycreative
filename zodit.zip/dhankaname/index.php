<?php 
	$conn=mysqli_connect("127.0.0.1","root","AMAN","raunak_jotit");
	if(!$conn){
		die(mysqli_connect_errno().' sorry this happened');
	}
	session_start();
	?>
	<?php 
	if( isset($_SESSION['username'])){
		$hide='true';
		$username=$_SESSION['username'];
	}
	?>
	<?php 
	if(isset($_GET['out'])){
		$_SESSION['username']=null;
		$username=null;
	}

	?>
<?php 
	// log in 
	if (isset($_POST["log_in"])){
		$name=$_POST['user-name'];
		$pas=$_POST['PASS-WORD'];
		$query="select username from loger where username='{$name}' and password='{$pas}'";
		$result=mysqli_query($conn,$query);
		if(!$result){$error1="SORRY NO USER";}
		else if($conter=mysqli_fetch_assoc($result))
			{$hide="true"; 
			$username=$conter['username'];
			$_SESSION['username']=$username;
	}
		else{
			$error1="SORRY NO USER";
		}
		}
?>
<?php 
	// sign up
	if (isset($_POST["slog_in"])){
		$name=strtolower($_POST['suser-name']);
		$pas=$_POST['sPASS-WORD'];

		$quer_schec="select count(*) as c from loger where username='{$name}'";
		$temp=mysqli_fetch_assoc(mysqli_query($conn,$quer_schec));
		if($temp['c']==0){
				$query="insert into loger(username,password) values ('{$name}', '{$pas}')";
				$result=mysqli_query($conn,$query);
				if(!$result){$error1="SORRY  USER edit PROBLEM";}
				else if($result)
					{$hide="true"; 
					$username=$name;
					$_SESSION['username']=$name;
					echo "done new user";
			}
				}
				else{
					$error="already a member";
				}
		}
?>
<?php  
	if(isset($_GET["sub"])){
		$filename=$_GET["nam_file"];
		$content=$_GET["note"];
		if(is_file('files/'.$filename.'.txt')){
		header("Location: 404.html");
		exit;
		}
		$hand=fopen('files/'.$filename.'.txt','w');
		fwrite($hand,$content);
		$query="INSERT INTO jotit(file,username) VALUES ('$filename','$username') ";
		$res=mysqli_query($conn,$query);
		if(!$res){die("ENTRY FAiLED");}
		else
			$_GET[]="";
		fclose($hand);
	}


?>
<?php 

		// left side click par get its content logic here

		if(isset($_GET['id'])){
		$query="SELECT *  FROM jotit where sno={$_GET['id']} and username='$username' limit 1";
		$result1=mysqli_query($conn,$query);
		if(!$result1){die("error");}
		$r=mysqli_fetch_assoc($result1);
		if(is_file('files/'.$r['file'].'.txt')){
			$file='files/'.$r['file'].'.txt';
			$handler=fopen('files/'.$r['file'].'.txt','r');
			$cont=fread($handler,filesize($file));
			// left side par click ke baad ka content

			fclose($handler);
		}
	}

?>
<?php 
	// Search logic here

	if(isset($_GET['searcher'])){
		$srch=strtolower($_GET['searcher']);
		$query="SELECT * FROM jotit where file like '%{$srch}%'";
		$result=mysqli_query($conn,$query);
		$value_srch=mysqli_fetch_assoc($result)['file'];
		if(isset($value_srch)){
			$file='files/'.$value_srch.'.txt';
			$handler=fopen('files/'.$value_srch.'.txt','r');
			$src=fread($handler,filesize($file));
			// search ke aane ke baad ka content
			fclose($handler);
		}


	}
?>


<script>

function ClearFields() {

     document.getElementById("textfield1").value = "";
     document.getElementById("textfield2").value = "";
}
</script>
<script>
   $(document).ready(function(){
          var scrollTo = getParameterByName('scrollTo');
          if(scrollTo!=''){
              $('html, body').animate({
                 scrollTop: $("#"+scrollTo).offset().top
               }, 1000);
          }
   });

   function getParameterByName(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }
</script>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Jot Down</title>
	<link rel="stylesheet" href="raun.css"></style>
	 <link href="css/font-awesome-4.6.1/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
		<div id="login-p" class="uniq" style="display: none;background-color: #644de1;z-index: 9909;">
          
          <h2>SIGN up</h2> To Continue..
          <div id="login-m">
            <form action="#" method="post">

                <span style="margin:20px">USERNAME:</span><input type="text" name="suser-name"><BR /><br>
                <span style="margin:20px">PASSWORD:</span><input type="PASSWORD" name="sPASS-WORD">
                <br>
                <input type="submit" name="slog_in" class="buton" style="background-color: white;width: 120px;border: none;height: 30px;margin:15px;color:black;background: -webkit-linear-gradient(left,  gray 18%,lightgray 52%)">

              </form>
              <br><hr>
              
          </div>

        </div>
	<div class="main">
			
			<div>
			<header><img src="jotdown.JPG" alt="jotit" class="jotitlogo">
			
			<?php if(isset($username)) { ?>
			<div style="position: absolute;top:-10;color: white;font-size:19px;margin:20px;right:20px">Welcome,<?php echo $username?>
				<form action="index.php" method="get"><input type="submit" name="out" value="log-out" style="width:100px;height:40px;margin: 5px 0; "></form>
			<?php 
			}  ?>
			</div>

			</header>
			</div>
			<div id="login-p1" <?php if(isset($username)){echo "style='display:none'";}?>>
          
          <h2>LOGIN</h2> To Continue..
          <div id="login-m">
          <?php 
          if(isset($error1)){
          	echo "{$error1}";
          }

          ?>


              <form action="#" method="post">

                <span style="margin:20px">USERNAME:</span><input type="text" name="user-name"><BR /><br>
                <span style="margin:20px">PASSWORD:</span><input type="PASSWORD" name="PASS-WORD">
                <br>
                <input type="submit" name="log_in" class="buton" style="background-color: white;width: 120px;border: none;height: 30px;margin:15px;color:black;background: -webkit-linear-gradient(left,  gray 18%,lightgray 52%)">

              </form>
              <br><hr>
              <div style="margin:10px;">
              BE A MEMBER
              <input type=submit value="SIGN UP" id="s-up" style="font-size:17px;height:22px;width:80px;padding: 3px;">
			  <script type="text/javascript">
			  	document.getElementById('s-up').addEventListener('click',function(){
			  		document.getElementsByClassName('uniq')[0].style.display="inline-block";
			  	});

			  </script>
			  </div>
          </div>

        </div>
		
			<div id="content-of-user" style="display: inline;position: absolute;top:50%;">
				<img src="paper.png" height="350" width="350" style="position: absolute;">
				<div style="z-index: 999;color:black;position: absolute;top: 112px;left: 63px;height: 150px;width: 190px;overflow: scroll"><?php if(!empty($cont) )print_r( $cont); 
						if(!empty($src)){echo $src;}
				?></div>

			</div>
			<div class="content" style="height: 100vh;clear:both">  
			<div id="left">
				<div id="searchdiv">
					<form action="" method="get" onsubmit="">
						 <input type="text" name="searcher" id="search" placeholder="search">
					 </form>
				 </div>
				<div id="recenthead">RECENT⇩</div>
				<?php  
				if((isset($username)))
				{$query="SELECT * FROM jotit where username='$username'";
								$result1=mysqli_query($conn,$query);
								if(!$result1){die("ERROR IN FETCHING DATA.. SORRY WE FIX IT SOON");}
								$i=1;
								while($r=mysqli_fetch_assoc($result1)) { 
									echo "<div id='spot{$i}' class='spot'>
										<a href='index.php?id={$r['sno']}' class ='file'>{$r['file']}</a>
									</div>";
									$i++;
								}
				}
				?>
			</div>
			<div id="right">
				<div id="form">
				<div id="jotit">
				Jot it.
				</div>
				<form action="" method="get">
				<input type="text" name="nam_file" id="name_file" placeholder="label">
				<br>
				<input type="text" name="note" id="note" placeholder="write new note">
					<br>
				<input type="submit" class="buton" value="Save It" name="sub" id="saveit" style="  background: radial-gradient(#FFF176, #F57F17)
;width: 40%;">
				
			   <input type="reset" class="buton" value="Clear All" onclick="ClearFields();" name="clear_all" id=saveit style="  background: radial-gradient(#FFF176, #F57F17)
;width: 40%;">
				</form>
				
				
				</div>
								
			</div>
		
	</div>

	</div>
<?php 

	if(isset($username) && !(empty($username))){
		?> <script type="text/javascript">document.getElementById('login-p1').style.display="none"; </script> <?php
	}
?>

</body>
</html>
