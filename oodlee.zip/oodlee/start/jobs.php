<?php 
    require_once('../private/includes/clas.php');
    session_start();
    if(!isset($_SESSION['uname'])){
        header('Location: index.php');
        exit;
    }
    if(!isset($_SESSION['oody_detail'])){
        header("Location: worker_details.php");
        exit;
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="js/vendor/external/jquery/jquery.js"></script>
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
        <script src="js/vendor/jquery-ui.js"></script>
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
        <link href='https://fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/normalize.css">
        <script type="text/javascript" src="js/vendor/modernizr-2.8.3.min.js"></script>
        <link href="css/font-awesome-4.6.1/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/jobs.css" rel="stylesheet">
        <script src="js/jobs.js" type="text/javascript"></script>
    </head> 
    <body>
    <?php 
        
        $query='SELECT * FROM  job where job_id='.$_SESSION["jobid"].' and sno_client='.$_SESSION["sno"].'';

        $x=$db->aray_result($db->query($query))[0];
        extract($x);

        
        ?>
        <div id="header"><img src="images/logo.png" id="ood-img">
<!--            yaha pr notifications wale icons php se ayenge-->
        </div>
        <div id="main">
        <div id="user-added-images">
            <!--        images ki location php se daalni h    -->
            <?php $qu="SELECT * from pictures where pic_id={$job_id}";
            $pict=$db->aray_result($db->query($qu))[0];
            ?>
            <img src="img/<?php echo $pict['pic1'] ?>" id="img-usr-1" class="img-usr">
            <img src="img/<?php echo $pict['pic2'] ?>" id="img-usr-2" class="img-usr">
            <img src="img/<?php echo $pict['pic3'] ?>" id="img-usr-3" class="img-usr">
        </div>
        <div id="user-info">
            <!--sab kuch php se ayega yahan pr-->
            <h1>TITLE</h1>
            <textarea id="oodTitle"><?php 
            echo $title;
            ?></textarea>
            <h1>Description</h1>
            <textarea id="oodDesc"><?php 
             echo $description;   
            ?></textarea>
            <h1>Category</h1><h2><?php echo strtoupper($category) ?></h2>
            <h1>Tags</h1>
            <textarea id="oodTags"><?php 
             echo $tag_id;   
            ?></textarea>
            <h1>Extra Requirements</h1>
            <textarea id="oodEx"><?php 
            echo $extra;   
            ?></textarea>
            <div id="some">
                <h1 id="oodPrice">Price:<?php echo $price?></h1>
                <h1 id="oodDel">DELIVERY:<?php echo $delivery_time?>-DAYS</h1>
            <span id="oodExtras">
            <div id="fast-add"><input type="checkbox" value="<?php echo addslashes($extra_fast)?>" id="fastum">Extra Fast Delivery</div>
            <br />
            <div id="chec-add"><input type="checkbox" value="<?php echo addslashes($extra_fast)?>" id="chec">Shipping</div>
            <br />
            <div><input type="checkbox" >Add Extra</div>
            </span></div>
            </div>
            <div id="option-btn">
                <input type="button" value="Reset" class="btn" id="ResetBtn">
                <input type="button" value="Submit" class="btn" id="ResetBtn">
            </div>
        </div>

    <?php 
    if( isset($shipping) && $shipping!=0){
        ?><script type="text/javascript">
        document.getElementById('chec').checked="checked";
        if($('#chec')[0].value!=0)
            $('#chec-add').append('=='+$('#chec')[0].value+"rs");
    </script>
        <?php
    }
    if(isset($extra_fast) && $extra_fast!=0){
        ?><script type="text/javascript">
        document.getElementById('fastum').checked="checked";
        if($('#fastum')[0].value!=0)
            $('#fast-add').append('=='+$('#fastum')[0].value+"rs");
    </script><?php
    }
    ?>
    </body>
</html>