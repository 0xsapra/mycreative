function Utility(){
this.taketotop=new function(){
	
}	
}