$(document).ready(function() {
    imgDis=false;
    $('#img-usr-2').click(function() {
        if(!imgDis) {
            $('#img-usr-1').show("slide", { direction: "right" }, 1000);
            $('#img-usr-3').show("slide", { direction: "up" }, 1000);
            imgDis=true;
        }
        else {
            $('#img-usr-1').hide("slide", { direction: "right" }, 1000);
            $('#img-usr-3').hide("slide", { direction: "up" }, 1000);
            imgDis=false;
        }
    });
});