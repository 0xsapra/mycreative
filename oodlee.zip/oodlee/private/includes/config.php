<?php
	define('DB_USER', 'root');
	define('DB_SERVER', '127.0.0.1');
	define('DB_PASS', 'AMAN');
	define('DB_NAME', 'voicebook');
	
?>