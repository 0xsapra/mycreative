<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("user",$con) or die(mysql_error());
?>
